package com.apu.seedshop.auth;

public enum AuthorityName {
    ROLE_USER, ROLE_MANAGER, ROLE_ADMIN
}